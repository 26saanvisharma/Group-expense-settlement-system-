package com.expense.model;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Represents a group of users who share expenses together
 * (e.g. roommates, a trip group, a project team).
 */
public class Group {
    private final String groupId;
    private final String name;
    private final List<User> members;
    private final List<Expense> expenses;

    public Group(String groupId, String name) {
        this.groupId = groupId;
        this.name = name;
        this.members = new ArrayList<>();
        this.expenses = new ArrayList<>();
    }

    public String getGroupId() {
        return groupId;
    }

    public String getName() {
        return name;
    }

    public List<User> getMembers() {
        return Collections.unmodifiableList(members);
    }

    public List<Expense> getExpenses() {
        return Collections.unmodifiableList(expenses);
    }

    public void addMember(User user) {
        if (!members.contains(user)) {
            members.add(user);
        }
    }

    public boolean hasMember(User user) {
        return members.contains(user);
    }

    public void addExpense(Expense expense) {
        expenses.add(expense);
    }

    @Override
    public String toString() {
        return name + " (" + groupId + ") - " + members.size() + " member(s)";
    }
}
