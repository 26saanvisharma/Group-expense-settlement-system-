package com.expense.model;

import java.time.LocalDate;
import java.util.Collections;
import java.util.List;
import java.util.Map;

/**
 * Represents a single shared expense within a group: who paid,
 * how much, who it was shared among, and how it was split.
 */
public class Expense {
    private static int counter = 1000;

    private final String expenseId;
    private final String description;
    private final double amount;
    private final User paidBy;
    private final List<User> participants;
    private final Map<User, Double> splitDetails;
    private final LocalDate date;

    public Expense(String description, double amount, User paidBy,
                    List<User> participants, Map<User, Double> splitDetails) {
        this.expenseId = "EXP" + (++counter);
        this.description = description;
        this.amount = amount;
        this.paidBy = paidBy;
        this.participants = participants;
        this.splitDetails = splitDetails;
        this.date = LocalDate.now();
    }

    public String getExpenseId() {
        return expenseId;
    }

    public String getDescription() {
        return description;
    }

    public double getAmount() {
        return amount;
    }

    public User getPaidBy() {
        return paidBy;
    }

    public List<User> getParticipants() {
        return Collections.unmodifiableList(participants);
    }

    public Map<User, Double> getSplitDetails() {
        return Collections.unmodifiableMap(splitDetails);
    }

    public LocalDate getDate() {
        return date;
    }

    @Override
    public String toString() {
        return String.format("[%s] %s | Rs.%.2f paid by %s on %s",
                expenseId, description, amount, paidBy.getName(), date);
    }
}
