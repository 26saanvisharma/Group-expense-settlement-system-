package com.expense.model;

/**
 * Represents a single settlement payment: 'from' pays 'to' a given amount
 * to clear part or all of their debt.
 */
public class Transaction {
    private final User from;
    private final User to;
    private final double amount;

    public Transaction(User from, User to, double amount) {
        this.from = from;
        this.to = to;
        this.amount = amount;
    }

    public User getFrom() {
        return from;
    }

    public User getTo() {
        return to;
    }

    public double getAmount() {
        return amount;
    }

    @Override
    public String toString() {
        return String.format("%s pays %s -> Rs.%.2f", from.getName(), to.getName(), amount);
    }
}
