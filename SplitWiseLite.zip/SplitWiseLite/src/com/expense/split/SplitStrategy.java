package com.expense.split;

import com.expense.exception.InvalidSplitException;
import com.expense.model.User;

import java.util.List;
import java.util.Map;

/**
 * Abstraction over different ways an expense amount can be divided
 * among participants. Implementations demonstrate polymorphism:
 * the ExpenseManager works with this interface without knowing
 * whether the split is Equal or Custom.
 */
public interface SplitStrategy {
    /**
     * Calculates how much each participant owes.
     *
     * @param totalAmount   total expense amount
     * @param participants  users sharing the expense
     * @param customAmounts custom share amounts (ignored by EqualSplit,
     *                      required by CustomSplit); may be null
     * @return map of each participant to the amount they owe
     * @throws InvalidSplitException if the split is invalid
     */
    Map<User, Double> calculateSplit(double totalAmount,
                                      List<User> participants,
                                      Map<User, Double> customAmounts) throws InvalidSplitException;
}
