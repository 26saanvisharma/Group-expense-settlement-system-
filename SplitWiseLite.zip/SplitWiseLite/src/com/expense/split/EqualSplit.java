package com.expense.split;

import com.expense.exception.InvalidSplitException;
import com.expense.model.User;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Divides the total amount equally among all participants.
 * Any remainder (due to rounding) is added to the first participant's
 * share so that the split always sums exactly to the total.
 */
public class EqualSplit implements SplitStrategy {

    @Override
    public Map<User, Double> calculateSplit(double totalAmount,
                                             List<User> participants,
                                             Map<User, Double> customAmounts) throws InvalidSplitException {
        if (participants == null || participants.isEmpty()) {
            throw new InvalidSplitException("Cannot split an expense with no participants.");
        }
        if (totalAmount <= 0) {
            throw new InvalidSplitException("Expense amount must be greater than zero.");
        }

        Map<User, Double> shares = new HashMap<>();
        int n = participants.size();
        double baseShare = Math.floor((totalAmount / n) * 100) / 100.0;
        double distributed = baseShare * n;
        double remainder = Math.round((totalAmount - distributed) * 100.0) / 100.0;

        for (int i = 0; i < n; i++) {
            double share = baseShare;
            if (i == 0) {
                share += remainder; // absorb rounding remainder
            }
            shares.put(participants.get(i), share);
        }
        return shares;
    }
}
