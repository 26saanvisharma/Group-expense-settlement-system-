package com.expense.split;

import com.expense.exception.InvalidSplitException;
import com.expense.model.User;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Splits the total amount according to caller-supplied custom shares.
 * The custom shares must include every participant and must sum
 * (within a small tolerance) to the total amount.
 */
public class CustomSplit implements SplitStrategy {

    private static final double TOLERANCE = 0.01;

    @Override
    public Map<User, Double> calculateSplit(double totalAmount,
                                             List<User> participants,
                                             Map<User, Double> customAmounts) throws InvalidSplitException {
        if (participants == null || participants.isEmpty()) {
            throw new InvalidSplitException("Cannot split an expense with no participants.");
        }
        if (customAmounts == null || customAmounts.isEmpty()) {
            throw new InvalidSplitException("Custom split requires explicit share amounts.");
        }

        double sum = 0.0;
        for (User u : participants) {
            Double share = customAmounts.get(u);
            if (share == null) {
                throw new InvalidSplitException("Missing custom share for participant: " + u.getName());
            }
            if (share < 0) {
                throw new InvalidSplitException("Custom share cannot be negative for: " + u.getName());
            }
            sum += share;
        }

        if (Math.abs(sum - totalAmount) > TOLERANCE) {
            throw new InvalidSplitException(
                    String.format("Custom shares (%.2f) do not add up to the expense total (%.2f).", sum, totalAmount));
        }

        return new HashMap<>(customAmounts);
    }
}
