package com.expense.service;

import com.expense.model.Transaction;
import com.expense.model.User;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.PriorityQueue;

/**
 * Reduces a set of member balances into the minimum number of
 * settlement transactions needed to clear all debts.
 *
 * Greedy algorithm: repeatedly match the member who is owed the
 * most (max creditor) with the member who owes the most (max debtor),
 * settle the smaller of the two amounts, and repeat until every
 * balance is zero. This is optimal in practice for typical group
 * sizes and is implemented using two priority queues.
 */
public class SettlementCalculator {

    private static final double EPSILON = 0.01;

    public List<Transaction> getMinimumTransactions(Map<User, Double> balances) {
        List<Transaction> transactions = new ArrayList<>();

        // Max-heap of creditors (people who are owed money, balance > 0)
        PriorityQueue<Map.Entry<User, Double>> creditors =
                new PriorityQueue<>(Comparator.comparingDouble((Map.Entry<User, Double> e) -> e.getValue()).reversed());
        // Max-heap of debtors (people who owe money, balance < 0) ordered by magnitude
        PriorityQueue<Map.Entry<User, Double>> debtors =
                new PriorityQueue<>(Comparator.comparingDouble((Map.Entry<User, Double> e) -> -e.getValue()));

        for (Map.Entry<User, Double> entry : balances.entrySet()) {
            if (entry.getValue() > EPSILON) {
                creditors.add(new java.util.AbstractMap.SimpleEntry<>(entry.getKey(), entry.getValue()));
            } else if (entry.getValue() < -EPSILON) {
                debtors.add(new java.util.AbstractMap.SimpleEntry<>(entry.getKey(), entry.getValue()));
            }
        }

        while (!creditors.isEmpty() && !debtors.isEmpty()) {
            Map.Entry<User, Double> topCreditor = creditors.poll();
            Map.Entry<User, Double> topDebtor = debtors.poll();

            double creditAmount = topCreditor.getValue();
            double debtAmount = -topDebtor.getValue(); // stored as negative

            double settleAmount = Math.round(Math.min(creditAmount, debtAmount) * 100.0) / 100.0;

            if (settleAmount > EPSILON) {
                transactions.add(new Transaction(topDebtor.getKey(), topCreditor.getKey(), settleAmount));
            }

            double remainingCredit = Math.round((creditAmount - settleAmount) * 100.0) / 100.0;
            double remainingDebt = Math.round((debtAmount - settleAmount) * 100.0) / 100.0;

            if (remainingCredit > EPSILON) {
                creditors.add(new java.util.AbstractMap.SimpleEntry<>(topCreditor.getKey(), remainingCredit));
            }
            if (remainingDebt > EPSILON) {
                debtors.add(new java.util.AbstractMap.SimpleEntry<>(topDebtor.getKey(), -remainingDebt));
            }
        }

        return transactions;
    }
}
