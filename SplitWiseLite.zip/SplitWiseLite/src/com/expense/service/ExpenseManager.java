package com.expense.service;

import com.expense.exception.InvalidExpenseException;
import com.expense.exception.InvalidSplitException;
import com.expense.exception.UserNotInGroupException;
import com.expense.model.Expense;
import com.expense.model.Group;
import com.expense.model.User;
import com.expense.split.SplitStrategy;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Central service that manages groups and expenses, and computes
 * running balances for each member of a group.
 *
 * Uses a HashMap<String, Group> for O(1) group lookup and keeps
 * per-group balances derived on demand from the expense history,
 * so the ledger is always consistent with recorded transactions.
 */
public class ExpenseManager {

    private final Map<String, Group> groups;
    private int groupCounter = 100;

    public ExpenseManager() {
        this.groups = new HashMap<>();
    }

    public Group createGroup(String groupName) {
        String groupId = "GRP" + (++groupCounter);
        Group group = new Group(groupId, groupName);
        groups.put(groupId, group);
        return group;
    }

    public Group getGroup(String groupId) {
        return groups.get(groupId);
    }

    public List<Group> getAllGroups() {
        return new java.util.ArrayList<>(groups.values());
    }

    public void addMemberToGroup(String groupId, User user) throws IllegalArgumentException {
        Group group = groups.get(groupId);
        if (group == null) {
            throw new IllegalArgumentException("No such group: " + groupId);
        }
        group.addMember(user);
    }

    /**
     * Records a new expense in a group using the given split strategy.
     * Validates that the payer and all participants belong to the group.
     */
    public Expense addExpense(String groupId, String description, double amount,
                               User paidBy, List<User> participants,
                               SplitStrategy strategy, Map<User, Double> customAmounts)
            throws InvalidExpenseException, InvalidSplitException, UserNotInGroupException {

        Group group = groups.get(groupId);
        if (group == null) {
            throw new InvalidExpenseException("No such group: " + groupId);
        }
        if (description == null || description.trim().isEmpty()) {
            throw new InvalidExpenseException("Expense description cannot be empty.");
        }
        if (amount <= 0) {
            throw new InvalidExpenseException("Expense amount must be positive.");
        }
        if (!group.hasMember(paidBy)) {
            throw new UserNotInGroupException(paidBy.getName() + " is not a member of group " + group.getName());
        }
        for (User p : participants) {
            if (!group.hasMember(p)) {
                throw new UserNotInGroupException(p.getName() + " is not a member of group " + group.getName());
            }
        }

        Map<User, Double> splitDetails = strategy.calculateSplit(amount, participants, customAmounts);
        Expense expense = new Expense(description, amount, paidBy, participants, splitDetails);
        group.addExpense(expense);
        return expense;
    }

    /**
     * Computes the net balance of every member in the group.
     * Positive balance  -> the group owes this member money.
     * Negative balance  -> this member owes the group money.
     */
    public Map<User, Double> calculateBalances(String groupId) {
        Group group = groups.get(groupId);
        Map<User, Double> balances = new HashMap<>();
        if (group == null) return balances;

        for (User member : group.getMembers()) {
            balances.put(member, 0.0);
        }

        for (Expense expense : group.getExpenses()) {
            // Payer is credited the full amount they paid
            balances.merge(expense.getPaidBy(), expense.getAmount(), Double::sum);
            // Each participant is debited their share
            for (Map.Entry<User, Double> entry : expense.getSplitDetails().entrySet()) {
                balances.merge(entry.getKey(), -entry.getValue(), Double::sum);
            }
        }

        // Round to 2 decimal places to avoid floating-point noise
        balances.replaceAll((user, bal) -> Math.round(bal * 100.0) / 100.0);
        return balances;
    }
}
