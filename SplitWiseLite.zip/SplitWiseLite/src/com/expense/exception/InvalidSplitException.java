package com.expense.exception;

/**
 * Thrown when an expense split does not add up correctly,
 * contains negative shares, or is otherwise malformed.
 */
public class InvalidSplitException extends Exception {
    public InvalidSplitException(String message) {
        super(message);
    }
}
