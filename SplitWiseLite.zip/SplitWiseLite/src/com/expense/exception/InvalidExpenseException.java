package com.expense.exception;

/**
 * Thrown when an expense has an invalid amount, description,
 * or no participants.
 */
public class InvalidExpenseException extends Exception {
    public InvalidExpenseException(String message) {
        super(message);
    }
}
