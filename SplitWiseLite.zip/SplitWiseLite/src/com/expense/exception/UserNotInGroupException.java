package com.expense.exception;

/**
 * Thrown when an operation references a user who is not
 * a member of the relevant group.
 */
public class UserNotInGroupException extends Exception {
    public UserNotInGroupException(String message) {
        super(message);
    }
}
