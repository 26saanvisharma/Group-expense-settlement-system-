# SplitWise Lite — Group Expense Settlement System

A Java OOP mini-project (CSC2104) that lets a group of people record
shared expenses, track running balances, and settle up using the
minimum possible number of payments.

## How to Compile and Run

```bash
# From the project root folder
javac -d bin $(find src -name "*.java")
java -cp bin Main
```

Tested with **Java 21** (openjdk-21-jdk-headless), but the code only
uses standard Java SE features and will run on Java 8+.

## Project Structure

```
SplitWiseLite/
├── README.md
└── src/
    ├── Main.java                          # Console menu / entry point
    └── com/expense/
        ├── model/
        │   ├── User.java                  # A group member
        │   ├── Group.java                 # A group of users + their expenses
        │   ├── Expense.java               # One recorded shared expense
        │   └── Transaction.java           # One settlement payment
        ├── split/
        │   ├── SplitStrategy.java         # Interface (abstraction)
        │   ├── EqualSplit.java            # Equal-share implementation
        │   └── CustomSplit.java           # Custom-amount implementation
        ├── exception/
        │   ├── InvalidExpenseException.java
        │   ├── InvalidSplitException.java
        │   └── UserNotInGroupException.java
        └── service/
            ├── ExpenseManager.java        # Groups, expenses, balance calc
            └── SettlementCalculator.java  # Minimum-transaction algorithm
```

## OOP Concepts Demonstrated

| Concept | Where |
|---|---|
| **Encapsulation** | Private fields with getters/setters in `User`, `Group`, `Expense` |
| **Abstraction** | `SplitStrategy` interface hides how a split is actually computed |
| **Polymorphism** | `ExpenseManager` works with any `SplitStrategy` (`EqualSplit` / `CustomSplit`) interchangeably |
| **Inheritance** | Custom exceptions extend `Exception` |
| **Exception Handling** | `InvalidExpenseException`, `InvalidSplitException`, `UserNotInGroupException` — all checked, all caught gracefully in `Main` |
| **Collections Framework** | `HashMap` (balances, group lookup), `ArrayList` (members, expenses, history), `PriorityQueue` (settlement algorithm) |

## Key Features

1. **Create groups & add members** — e.g. "Goa Trip" with Alice, Bob, Charlie.
2. **Add expenses** with either:
   - **Equal split** — divides evenly, absorbing any rounding remainder.
   - **Custom split** — caller supplies each participant's exact share; validated to sum to the total.
3. **Balance calculation** — running per-member balance (owed / owes), derived fresh from expense history via `ExpenseManager.calculateBalances()`.
4. **Minimum settlement summary** — `SettlementCalculator` uses a **greedy algorithm with two priority queues** (max-creditor heap and max-debtor heap) to reduce N debts to the fewest possible transactions.
5. **Transaction / expense history** — every expense and its split breakdown is stored and viewable.
6. **Robust exception handling** — negative amounts, empty groups, non-members, and mismatched custom splits are all caught with meaningful messages instead of crashing.

## Sample Run

```
1. Create Group        -> "Goa Trip"
2. Add Member           -> Alice, Bob, Charlie
3. Add Expense           -> "Hotel Booking", Rs.6000, paid by Alice, split equally
4. View Balances         -> Alice: +4000 | Bob: -2000 | Charlie: -2000
5. Settlement Summary    -> Bob pays Alice Rs.2000
                             Charlie pays Alice Rs.2000
```

## Possible Extensions (for viva / future work)

- Persist groups/expenses to a file (`File Handling`) so data survives restarts.
- Add a `PercentageSplit` strategy (another `SplitStrategy` implementation).
- Add a simple Swing or JavaFX GUI on top of the same `ExpenseManager` / `SettlementCalculator` classes — no changes needed to the core logic.
