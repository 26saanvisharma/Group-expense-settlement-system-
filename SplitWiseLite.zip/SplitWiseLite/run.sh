#!/bin/bash
# SplitWise Lite - compile and run (Mac/Linux)
echo "Compiling..."
javac -d bin $(find src -name "*.java")
if [ $? -eq 0 ]; then
    echo "Compiled successfully. Starting program..."
    echo ""
    java -cp bin Main
else
    echo "Compilation failed. Please check the error above."
fi
