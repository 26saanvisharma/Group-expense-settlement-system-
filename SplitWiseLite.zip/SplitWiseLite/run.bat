@echo off
REM SplitWise Lite - compile and run (Windows)
echo Compiling...
javac -d bin src\Main.java src\com\expense\model\*.java src\com\expense\split\*.java src\com\expense\exception\*.java src\com\expense\service\*.java
if %errorlevel% neq 0 (
    echo Compilation failed. Please check the error above.
    pause
    exit /b
)
echo Compiled successfully. Starting program...
echo.
java -cp bin Main
pause
